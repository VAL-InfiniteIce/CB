var searchData=
[
  ['dict_2ec',['dict.c',['../dict_8c.html',1,'']]],
  ['dict_2eh',['dict.h',['../dict_8h.html',1,'']]]
];
