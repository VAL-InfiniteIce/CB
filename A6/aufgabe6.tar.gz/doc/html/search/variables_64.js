var searchData=
[
  ['data',['data',['../dict_8h.html#ab6e3fda55d9ad7a27cf12f7f599e842f',1,'dict_t']]],
  ['decl',['decl',['../symtab_8h.html#a222b6f0fb517128a1726a5d75c5dfece',1,'symtab_t']]],
  ['dispatchtable',['dispatchTable',['../minako_8c.html#aabd0339853ce476f02e0da0e772dc6fa',1,'minako.c']]]
];
