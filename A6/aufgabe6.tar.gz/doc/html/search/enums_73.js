var searchData=
[
  ['syntree_5fnode_5ftag',['syntree_node_tag',['../syntree_8h.html#afcb8b50a3f680e5740ce172fc28463c8',1,'syntree.h']]],
  ['syntree_5fnode_5ftype',['syntree_node_type',['../syntree_8h.html#aab94349306c4f00232fa7a54212c0352',1,'syntree.h']]]
];
