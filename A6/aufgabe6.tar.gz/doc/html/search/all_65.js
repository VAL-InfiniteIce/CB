var searchData=
[
  ['eax',['eax',['../minako_8c.html#a763f70730744060250bd9799bc322e2d',1,'minako_vm_t']]],
  ['ebp',['ebp',['../minako_8c.html#a6849e1af510810a81e8975580750475a',1,'minako_vm_t']]],
  ['esp',['esp',['../minako_8c.html#a9250cbe27b357a2cd9f01c805eba4c38',1,'minako_vm_t']]]
];
