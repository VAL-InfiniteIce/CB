var syntree_8h_structsyntree__node__t =
[
    [ "syntree_node_value_u", "syntree_8h.html#unionsyntree__node__t_1_1syntree__node__value__u", [
      [ "boolean", "syntree_8h.html#a0bd6fcccf3fe2898a0757ac39f0ada1e", null ],
      [ "container", "syntree_8h.html#a42c09b9d7e086a2b05d875caf141cd64", null ],
      [ "function", "syntree_8h.html#a9b354e3e77134a3e7479d49d8992a3a4", null ],
      [ "integer", "syntree_8h.html#adf22496ae104d783733b3c3738d3cf1a", null ],
      [ "program", "syntree_8h.html#aa62825c330a4aac3a9318ba16de68bd0", null ],
      [ "real", "syntree_8h.html#a4a34b7ca814ce268ffc0ac0be198e17d", null ],
      [ "string", "syntree_8h.html#ab6d7ca5b03b0cafa62d37b972c3495a7", null ],
      [ "variable", "syntree_8h.html#a5e30d3692a26a0328c957816ad73542f", null ]
    ] ],
    [ "syntree_node_value_u.container", "syntree_8h.html#structsyntree__node__t_1_1syntree__node__value__u_8container", [
      [ "first", "syntree_8h.html#a8b04d5e3775d298e78455efc5ca404d5", null ],
      [ "last", "syntree_8h.html#a98bd1c45684cf587ac2347a92dd7bb51", null ]
    ] ],
    [ "syntree_node_value_u.function", "syntree_8h.html#structsyntree__node__t_1_1syntree__node__value__u_8function", [
      [ "body", "syntree_8h.html#a841a2d689ad86bd1611447453c22c6fc", null ],
      [ "locals", "syntree_8h.html#a65004f81079422462f2162dcf38954f3", null ]
    ] ],
    [ "syntree_node_value_u.program", "syntree_8h.html#structsyntree__node__t_1_1syntree__node__value__u_8program", [
      [ "body", "syntree_8h.html#a841a2d689ad86bd1611447453c22c6fc", null ],
      [ "globals", "syntree_8h.html#a0c54ed5f674437c1eba26ffc6c786909", null ]
    ] ],
    [ "next", "syntree_8h.html#a62ca8a9dbd404917f3c7ece4c2462cb4", null ],
    [ "tag", "syntree_8h.html#a7fba3f66a264835defc58510af48cb95", null ],
    [ "type", "syntree_8h.html#a0a367c5debb8a574f9afa55c5043a132", null ]
];