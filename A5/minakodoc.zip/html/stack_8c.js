var stack_8c =
[
    [ "stackCount", "stack_8c.html#af1427ec650142ab87740e712aed037f3", null ],
    [ "stackInit", "stack_8c.html#af32139a2704f603c9c2916df0f3eb2c6", null ],
    [ "stackIsEmpty", "stack_8c.html#a0c1cf707e696ac585e95ec8a1beac43d", null ],
    [ "stackPop", "stack_8c.html#a595af524b6a6ddc6d1d82430349acf94", null ],
    [ "stackPush", "stack_8c.html#a26de7d47ef7b401dc53161798dac16fb", null ],
    [ "stackRelease", "stack_8c.html#ab1e2fce9e4ddcef62c1eac535b53b32a", null ]
];