var symtab_8h_structsymtab__symbol__t =
[
    [ "body", "symtab_8h.html#a0dcb516620140f6955306f95c7fa111f", null ],
    [ "id", "symtab_8h.html#a02f86889ac7e95d71e815255dc73a72f", null ],
    [ "is_function", "symtab_8h.html#a56643eab1cb3b6daf761ec2fddc2c26f", null ],
    [ "is_global", "symtab_8h.html#aece20754561d800fa8b288e0bfe2c102", null ],
    [ "is_param", "symtab_8h.html#a1be7d3e07efb942d97dee429591e3978", null ],
    [ "name", "symtab_8h.html#aa5de10849cae382bdc5004818789730b", null ],
    [ "par_next", "symtab_8h.html#ab05fa80e6229088cf8d0c1040b317dc0", null ],
    [ "pos", "symtab_8h.html#a23503d256b36d34cd693649d92c7044a", null ],
    [ "rec_prev", "symtab_8h.html#a57259ac097eed6980bae91cf38076596", null ],
    [ "type", "symtab_8h.html#a6a4de2d66e3d3944eef2109ab4953c74", null ]
];