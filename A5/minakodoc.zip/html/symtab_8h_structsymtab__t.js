var symtab_8h_structsymtab__t =
[
    [ "block", "symtab_8h.html#ac8e81a735f3067ba9a18e066ccfc07b4", null ],
    [ "decl", "symtab_8h.html#a222b6f0fb517128a1726a5d75c5dfece", null ],
    [ "map", "symtab_8h.html#a3f27ffd31fd7a4e42ab2cad13d189119", null ],
    [ "maxpos", "symtab_8h.html#a1ff40ad4336a84242c02448eff5dc02c", null ]
];