var NAVTREE =
[
  [ "Minako", "index.html", [
    [ "Einführung", "index.html#Einführung", null ],
    [ "Syntax", "index.html#Syntax", null ],
    [ "Semantik", "index.html#Semantik", null ],
    [ "Datenstrukturen", "annotated.html", [
      [ "Datenstrukturen", "annotated.html", "annotated_dup" ],
      [ "Datenstruktur-Elemente", "functions.html", [
        [ "Alle", "functions.html", null ],
        [ "Variablen", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Dateien", null, [
      [ "Auflistung der Dateien", "files.html", "files" ],
      [ "Datei-Elemente", "globals.html", [
        [ "Alle", "globals.html", null ],
        [ "Funktionen", "globals_func.html", null ],
        [ "Variablen", "globals_vars.html", null ],
        [ "Typdefinitionen", "globals_type.html", null ],
        [ "Aufzählungen", "globals_enum.html", null ],
        [ "Makrodefinitionen", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html"
];

var SYNCONMSG = 'Klicken um Panelsynchronisation auszuschalten';
var SYNCOFFMSG = 'Klicken um Panelsynchronisation einzuschalten';