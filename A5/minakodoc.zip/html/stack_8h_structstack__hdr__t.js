var stack_8h_structstack__hdr__t =
[
    [ "cap", "stack_8h.html#af62eae1620714e1ec1f543554287b83c", null ],
    [ "len", "stack_8h.html#ac5d42e3e8aad604f5237c7f22a45a71a", null ]
];