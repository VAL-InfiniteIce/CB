var stack_8h =
[
    [ "stack_hdr_t", "stack_8h.html#structstack__hdr__t", [
      [ "cap", "stack_8h.html#af62eae1620714e1ec1f543554287b83c", null ],
      [ "len", "stack_8h.html#ac5d42e3e8aad604f5237c7f22a45a71a", null ]
    ] ],
    [ "stackInit", "stack_8h.html#aa8936341df35acb800bff9f35d6dffb6", null ],
    [ "stackPop", "stack_8h.html#ad372dc34538d4f5dd65ca4484785c35a", null ],
    [ "stackPush", "stack_8h.html#a18d6f21f8031e34d1113a1797ae5f2a8", null ],
    [ "stackTop", "stack_8h.html#ab6e5bbacb2355131579df137d6b489da", null ],
    [ "stackCount", "stack_8h.html#af1427ec650142ab87740e712aed037f3", null ],
    [ "stackInit", "stack_8h.html#aca6d35ef51d076397ff26f830f0d39bc", null ],
    [ "stackIsEmpty", "stack_8h.html#a0c1cf707e696ac585e95ec8a1beac43d", null ],
    [ "stackPop", "stack_8h.html#aed8fc083da53ad733961b03e48e127e4", null ],
    [ "stackPush", "stack_8h.html#a30c87de3db21f1d86639487afa98f542", null ],
    [ "stackRelease", "stack_8h.html#ab1e2fce9e4ddcef62c1eac535b53b32a", null ]
];