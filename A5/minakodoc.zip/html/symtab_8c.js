var symtab_8c =
[
    [ "symtabEnter", "symtab_8c.html#ad0bb9d863a33cb62ca7217f84e40cc50", null ],
    [ "symtabInit", "symtab_8c.html#ad68de968895824dd7c346389f2a5b4fb", null ],
    [ "symtabInsert", "symtab_8c.html#a0d61f8a97ef38ccf30b38d8d2205602b", null ],
    [ "symtabIsGlobal", "symtab_8c.html#a0471c0e6285a26d45650053915ae780c", null ],
    [ "symtabLeave", "symtab_8c.html#a4e0a472001616d30c1be096bac56773b", null ],
    [ "symtabLookup", "symtab_8c.html#a69eb5df8255d1c04899264d20ea6f944", null ],
    [ "symtabMaxGlobals", "symtab_8c.html#ad71ea85f0fbd3fd9c4bcfff36d77e362", null ],
    [ "symtabMaxLocals", "symtab_8c.html#a056912f26cde3773f18c86973c9effe3", null ],
    [ "symtabParam", "symtab_8c.html#a479404d04b136790176ebddc366fdd0b", null ],
    [ "symtabParamFirst", "symtab_8c.html#abfbfafe2eb4c05069353a3eae6d0b4d9", null ],
    [ "symtabParamNext", "symtab_8c.html#ad576a32ccb1be39f521bec429b8e53c6", null ],
    [ "symtabPrint", "symtab_8c.html#ad453a8041ee4541cdd063a58142aae8e", null ],
    [ "symtabRelease", "symtab_8c.html#a786d1742a4f3e7f3b17e77e66aa8f42d", null ],
    [ "symtabSymbol", "symtab_8c.html#af301b560e63c34a3b5996ea5a15c9a0a", null ],
    [ "symtabSymbolFree", "symtab_8c.html#a47696ca1b4e5325ee576c7f8840ebb8a", null ]
];