var searchData=
[
  ['real',['real',['../syntree_8h.html#a4a34b7ca814ce268ffc0ac0be198e17d',1,'syntree_node_t::syntree_node_value_u']]],
  ['rec_5fprev',['rec_prev',['../symtab_8h.html#a57259ac097eed6980bae91cf38076596',1,'symtab_symbol_t']]]
];
