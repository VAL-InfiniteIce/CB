var searchData=
[
  ['locate_5fresult_5ft',['locate_result_t',['../dict_8c.html#structlocate__result__t',1,'']]]
];
