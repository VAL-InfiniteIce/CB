var indexSectionsWithContent =
{
  0: "bcdfghiklmnprstv",
  1: "dls",
  2: "ds",
  3: "dfgls",
  4: "bcdfiklmnprstv",
  5: "hs",
  6: "s",
  7: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "defines"
};

var indexSectionLabels =
{
  0: "Alle",
  1: "Datenstrukturen",
  2: "Dateien",
  3: "Funktionen",
  4: "Variablen",
  5: "Typdefinitionen",
  6: "Aufzählungen",
  7: "Makrodefinitionen"
};

