var dict_8h_structdict__t =
[
    [ "bits", "dict_8h.html#ab359949283466147f5203c1df7495912", null ],
    [ "data", "dict_8h.html#ab6e3fda55d9ad7a27cf12f7f599e842f", null ],
    [ "left", "dict_8h.html#ad6d6c4716af63f48b1e788823f053b60", null ]
];