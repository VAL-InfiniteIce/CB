var files =
[
    [ "dict.c", "dict_8c.html", "dict_8c" ],
    [ "dict.h", "dict_8h.html", "dict_8h" ],
    [ "stack.c", "stack_8c.html", "stack_8c" ],
    [ "stack.h", "stack_8h.html", "stack_8h" ],
    [ "symtab.c", "symtab_8c.html", "symtab_8c" ],
    [ "symtab.h", "symtab_8h.html", "symtab_8h" ],
    [ "syntree.c", "syntree_8c.html", "syntree_8c" ],
    [ "syntree.h", "syntree_8h.html", "syntree_8h" ]
];